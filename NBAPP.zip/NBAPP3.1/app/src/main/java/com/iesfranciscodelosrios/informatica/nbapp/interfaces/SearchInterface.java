package com.iesfranciscodelosrios.informatica.nbapp.interfaces;

public interface SearchInterface {

    public interface View {
        void buttonSearch();
        void UpButton();

    }
    public interface Presenter {
        void buttonSearch();
        void UpButton();
    }
}

