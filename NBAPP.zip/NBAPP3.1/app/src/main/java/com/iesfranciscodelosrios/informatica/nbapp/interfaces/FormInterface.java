package com.iesfranciscodelosrios.informatica.nbapp.interfaces;

public interface FormInterface {

    public interface View {
        void buttonSave();
        void UpButton();

    }
    public interface Presenter {
        void buttonSave();
        void UpButton();
    }
}

