package com.iesfranciscodelosrios.informatica.nbapp.interfaces;

public interface AboutMeInterface {

        public interface View {
            void UpButton();

        }
        public interface Presenter {
            void UpButton();
        }

    }


